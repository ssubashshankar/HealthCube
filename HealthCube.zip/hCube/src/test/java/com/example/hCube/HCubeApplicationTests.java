package com.example.hCube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HCubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
