package com.example.hCube;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HCubeApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(HCubeApplication.class, args);
	}


}
